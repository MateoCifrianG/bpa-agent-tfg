# CÓMO INSTALAR ESTA SKILL EN CLAUDE CODE

## OPCIÓN A — Dar el ZIP directamente a Claude Code

Pega este mensaje en Claude Code apuntando al ZIP:

```
Tengo el ZIP de mi skill en ~/Downloads/bpa-agent-skill.zip (o donde lo hayas guardado).

Haz exactamente esto:
1. Descomprime el ZIP: unzip ~/Downloads/bpa-agent-skill.zip -d /tmp/bpa-skill
2. Crea la carpeta: mkdir -p .claude/skills
3. Copia la skill: cp -r /tmp/bpa-skill/bpa-agent .claude/skills/
4. Lee .claude/skills/bpa-agent/SKILL.md
5. Lee .claude/skills/bpa-agent/references/01_ESTADO.md
6. Ejecuta: python .claude/skills/bpa-agent/scripts/check_env.py
7. Dime qué ha encontrado el validador y cuál es el primer paso concreto para arrancar la Fase 0
```

---

## OPCIÓN B — Desde cualquier ubicación

```
El ZIP de mi TFG está en: [RUTA COMPLETA AL ZIP]

Instálalo en este proyecto:
1. Extrae el ZIP y copia la carpeta bpa-agent/ dentro de .claude/skills/
2. Verifica que .claude/skills/bpa-agent/SKILL.md existe
3. Lee ese SKILL.md y el references/01_ESTADO.md
4. Ejecuta scripts/check_env.py y dime qué falta para arrancar
```

---

## VERIFICAR QUE FUNCIONA

Una vez instalada, en cualquier sesión nueva escribe:
```
/bpa-agent
```
O simplemente trabaja con normalidad — Claude activará la skill automáticamente al
detectar que estás trabajando en el proyecto BPA.

---

## ESTRUCTURA QUE DEBE QUEDAR

```
tu-proyecto/
└── .claude/
    └── skills/
        └── bpa-agent/
            ├── SKILL.md                    ← Entry point
            ├── references/
            │   ├── 01_ESTADO.md
            │   ├── 02_ARQUITECTURA.md
            │   ├── 03_SEGURIDAD.md
            │   ├── 04_STACK.md
            │   ├── 05_AGENTE_IA.md
            │   ├── 06_FRONTEND.md
            │   └── 07_09_TESTS_DEPLOY_MEMORIA.md
            └── scripts/
                ├── check_env.py
                ├── audit_security.py
                └── seed_db.py
```
