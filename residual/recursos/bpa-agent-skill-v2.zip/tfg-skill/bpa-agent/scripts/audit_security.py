#!/usr/bin/env python3
"""audit_security.py — Auditoría de seguridad pre-commit. Sin dependencias externas."""
import re, sys, subprocess
from pathlib import Path

R="\033[91m"; G="\033[92m"; Y="\033[93m"; X="\033[0m"
criticos=[]; avisos=[]

def buscar(patron, exts, excluir=None):
    excluir = excluir or []
    excluir_dirs = {"node_modules",".git","__pycache__",".next","venv",".venv","dist","build"}
    hits = []
    for ext in exts:
        for f in Path(".").rglob(f"*.{ext}"):
            if any(d in f.parts for d in excluir_dirs): continue
            if str(f) in excluir: continue
            try:
                for i, l in enumerate(f.read_text(errors="ignore").splitlines(), 1):
                    if re.search(patron, l, re.I):
                        hits.append((str(f), i, l.strip()[:100]))
            except: pass
    return hits

print(f"\n🔐 BPA-Agent — Auditoría de Seguridad Pre-commit\n{'='*48}\n")

# 1. Credenciales en código
print("1. Credenciales hardcodeadas...")
for pat, desc, excs in [
    (r'sk-ant-[a-zA-Z0-9\-]{20,}',         "API Key Anthropic",  ["audit_security.py"]),
    (r'ANTHROPIC_API_KEY\s*=\s*["\']sk-',   "API Key en asignación", [".env.example","audit_security.py"]),
    (r'password\s*=\s*["\'][^"\'<{]{4,}',   "Password literal",   [".env.example","conftest.py"]),
    (r'secret_key\s*=\s*["\'][^"\'<{]{8,}', "Secret key literal", [".env.example","audit_security.py"]),
    (r'postgresql://[^${\s].*:(?!.*\$)[^@\s]{4,}@',"Creds DB en URL",[".env.example"]),
]:
    hits = buscar(pat, ["py","ts","tsx","js","env"], excs)
    for f,l,c in hits:
        print(f"  {R}🚨 {desc} → {f}:{l}{X}")
        criticos.append(f"{desc} en {f}:{l}")
if not any(criticos): print(f"  {G}✓ Ninguna encontrada{X}")

# 2. .env en git
print("\n2. .env en git...")
r = subprocess.run(["git","ls-files",".env"], capture_output=True, text=True)
if r.returncode==0 and r.stdout.strip():
    print(f"  {R}🚨 .env está en git → git rm --cached .env{X}")
    criticos.append(".env en git")
else:
    print(f"  {G}✓ .env no trackeado{X}")

# 3. SQL dinámico
print("\n3. SQL dinámico (inyección)...")
hits = buscar(r'(f["\']|format\s*\().*\b(SELECT|INSERT|UPDATE|DELETE)\b', ["py"])
for f,l,c in hits:
    print(f"  {R}🚨 SQL dinámico → {f}:{l}: {c}{X}")
    criticos.append(f"SQL dinámico en {f}:{l}")
if not hits: print(f"  {G}✓ No encontrado{X}")

# 4. CORS wildcard
print("\n4. CORS wildcard...")
hits = buscar(r'allow_origins.*["\'\[]\s*\*', ["py"])
for f,l,c in hits:
    print(f"  {Y}⚠  CORS wildcard → {f}:{l} (OK en dev, NO en prod){X}")
    avisos.append(f"CORS wildcard en {f}:{l}")
if not hits: print(f"  {G}✓ CORS explícito{X}")

# 5. Prompt injection — input a Claude sin sanitizar
print("\n5. Input a Claude sin sanitizar...")
hits = buscar(r'client\.messages\.(create|stream)', ["py"])
unsafe = [h for h in hits if not any(
    buscar(r'sanitize_user_input', ["py"])
)]
if unsafe:
    print(f"  {Y}⚠  Verificar que sanitize_user_input() se llama antes de cada llamada a Claude{X}")
    avisos.append("Revisar sanitización antes de Claude API")
else:
    print(f"  {G}✓ Sanitización detectada{X}")

# 6. print() con datos sensibles
print("\n6. print() con datos sensibles...")
hits = buscar(r'print\s*\(.*\b(password|token|api_key|secret)\b', ["py"])
for f,l,c in hits:
    print(f"  {Y}⚠  Log sensible → {f}:{l}: {c}{X}")
    avisos.append(f"Log sensible en {f}:{l}")
if not hits: print(f"  {G}✓ No encontrado{X}")

# Resumen
print(f"\n{'='*48}")
print(f"RESUMEN:  🚨 Críticos: {len(criticos)}   ⚠️  Avisos: {len(avisos)}")
if criticos:
    print(f"\n{R}RESOLVER ANTES DE COMMITEAR:{X}")
    for c in criticos: print(f"  • {c}")
    sys.exit(1)
elif avisos:
    print(f"\n{Y}Revisar antes de hacer push a producción.{X}")
else:
    print(f"\n{G}✅ Sin problemas críticos. Seguro para commit.{X}")
