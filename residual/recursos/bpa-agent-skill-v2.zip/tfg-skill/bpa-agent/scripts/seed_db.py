#!/usr/bin/env python3
"""
seed_db.py — Carga la empresa demo Ferretería Goikoetxea S.L. en la BD.
Ejecutar UNA VEZ tras crear las tablas: python .claude/skills/bpa-agent/scripts/seed_db.py
"""
import asyncio, json, sys, os
from datetime import date, timedelta
from uuid import uuid4

# Añadir backend al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'backend'))

EMPRESA_ID = "demo-goikoetxea-0001-0000-000000000001"

DEMO = {
    "empresa": {
        "id": EMPRESA_ID,
        "nombre": "Ferretería Goikoetxea S.L.",
        "sector": "Distribución industrial",
        "tamaño": "pequeña",
        "descripcion": "Distribuidor de materiales de construcción y ferretería industrial en el País Vasco. 12 empleados, 3 comerciales, 2 administrativos. Facturación anual ~2M€.",
    },
    "procesos": [
        {
            "id": "proc-0001",
            "nombre": "Gestión de pedidos por email",
            "descripcion": "Los clientes envían pedidos por email. Un administrativo los lee, introduce manualmente en el ERP, confirma stock y responde. 15-20 emails/día. Propenso a errores y retrasos.",
            "frecuencia": "diario",
            "tiempo_manual_horas": 2.5,
            "herramientas_actuales": ["Gmail", "Excel", "ERP Sage"],
            "score_ineficiencia": 88.0,
            "score_automatizabilidad": 75.0,
        },
        {
            "id": "proc-0002",
            "nombre": "Informe semanal de ventas",
            "descripcion": "Cada lunes el gerente solicita informe de ventas. Un administrativo exporta del ERP a Excel, crea gráficas y envía por email. 2-3 horas cada semana.",
            "frecuencia": "semanal",
            "tiempo_manual_horas": 2.5,
            "herramientas_actuales": ["Excel", "ERP Sage", "Gmail"],
            "score_ineficiencia": 92.0,
            "score_automatizabilidad": 90.0,
        },
        {
            "id": "proc-0003",
            "nombre": "Seguimiento de presupuestos pendientes",
            "descripcion": "Los comerciales envían presupuestos pero no hay sistema de seguimiento. Semanalmente revisan manualmente qué presupuestos no han recibido respuesta.",
            "frecuencia": "semanal",
            "tiempo_manual_horas": 1.5,
            "herramientas_actuales": ["Gmail", "Excel"],
            "score_ineficiencia": 85.0,
            "score_automatizabilidad": 88.0,
        },
        {
            "id": "proc-0004",
            "nombre": "Onboarding de nuevos proveedores",
            "descripcion": "Alta de proveedor: recopilar documentación, introducir en sistema, crear carpeta en Drive. Proceso manual, sin estandarizar, tarda 3h por proveedor.",
            "frecuencia": "mensual",
            "tiempo_manual_horas": 3.0,
            "herramientas_actuales": ["Gmail", "Google Drive", "ERP Sage"],
            "score_ineficiencia": 78.0,
            "score_automatizabilidad": 72.0,
        },
    ],
    "automatizaciones": [
        {
            "id": "auto-0001",
            "proceso_id": "proc-0001",
            "nombre": "Respuesta automática + registro de pedidos",
            "descripcion": "Al recibir email de pedido: extraer datos, registrar en hoja Drive, enviar confirmación automática al cliente con número de pedido asignado.",
            "tipo": "email",
            "estado": "activa",
            "tiempo_ahorrado_horas_semana": 1.5,
            "roi_estimado": 1950.0,
            "activada_at": (date.today() - timedelta(weeks=4)).isoformat(),
            "config": {
                "trigger": "email_recibido",
                "filtros_asunto": ["pedido", "order", "solicitud", "compra"],
                "accion_1": {"tipo": "registrar_drive", "hoja": "Pedidos 2025"},
                "accion_2": {"tipo": "responder_email", "plantilla": "confirmacion_pedido"},
            }
        },
        {
            "id": "auto-0002",
            "proceso_id": "proc-0002",
            "nombre": "Informe de ventas automático — lunes 8:00",
            "descripcion": "Cada lunes a las 8:00, generar informe de ventas de la semana anterior desde datos en Drive, crear documento Google Docs y enviarlo por email al gerente.",
            "tipo": "calendario",
            "estado": "activa",
            "tiempo_ahorrado_horas_semana": 2.5,
            "roi_estimado": 3250.0,
            "activada_at": (date.today() - timedelta(weeks=4)).isoformat(),
            "config": {
                "trigger": "cron",
                "horario": "0 8 * * 1",
                "fuente_datos": "google_drive",
                "plantilla": "informe_ventas_semanal",
                "destinatarios": ["gerente@goikoetxea.com"],
            }
        },
    ],
    "kpi_snapshots": [
        {
            "fecha": (date.today() - timedelta(weeks=3)).isoformat(),
            "tareas_automatizadas": 31, "horas_ahorradas_semana": 4.0,
            "roi_acumulado": 400.0,  "automatizaciones_activas": 2,
        },
        {
            "fecha": (date.today() - timedelta(weeks=2)).isoformat(),
            "tareas_automatizadas": 28, "horas_ahorradas_semana": 4.0,
            "roi_acumulado": 800.0,  "automatizaciones_activas": 2,
        },
        {
            "fecha": (date.today() - timedelta(weeks=1)).isoformat(),
            "tareas_automatizadas": 35, "horas_ahorradas_semana": 4.0,
            "roi_acumulado": 1200.0, "automatizaciones_activas": 2,
        },
        {
            "fecha": date.today().isoformat(),
            "tareas_automatizadas": 33, "horas_ahorradas_semana": 4.0,
            "roi_acumulado": 1600.0, "automatizaciones_activas": 2,
        },
    ]
}

async def seed():
    print("\n🌱 Cargando empresa demo Goikoetxea...\n")
    try:
        from app.database import engine
        from app.models.base import Base
        from app.models.empresa import Empresa
        from app.models.proceso import Proceso
        from app.models.automatizacion import Automatizacion
        from app.models.kpi import KPISnapshot
        from sqlalchemy.ext.asyncio import AsyncSession

        async with AsyncSession(engine) as db:
            # Empresa
            db.add(Empresa(**DEMO["empresa"]))
            await db.flush()
            print(f"✅ Empresa: {DEMO['empresa']['nombre']}")

            # Procesos
            for p in DEMO["procesos"]:
                db.add(Proceso(empresa_id=EMPRESA_ID, **p))
            await db.flush()
            print(f"✅ Procesos: {len(DEMO['procesos'])} creados")

            # Automatizaciones
            for a in DEMO["automatizaciones"]:
                db.add(Automatizacion(**a))
            await db.flush()
            print(f"✅ Automatizaciones: {len(DEMO['automatizaciones'])} creadas")

            # KPIs
            for k in DEMO["kpi_snapshots"]:
                db.add(KPISnapshot(id=str(uuid4()), empresa_id=EMPRESA_ID, **k))
            await db.commit()
            print(f"✅ KPI Snapshots: {len(DEMO['kpi_snapshots'])} semanas de historia")

        print(f"\n🎉 Seed completado. Empresa ID: {EMPRESA_ID}")
        print(f"   Dashboard: http://localhost:3000/empresa/{EMPRESA_ID}")

    except ImportError:
        print("⚠️  Modelos no disponibles. Datos demo para referencia:")
        print(json.dumps(DEMO, indent=2, ensure_ascii=False, default=str))

if __name__ == "__main__":
    asyncio.run(seed())
