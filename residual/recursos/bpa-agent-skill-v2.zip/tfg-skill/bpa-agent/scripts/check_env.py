#!/usr/bin/env python3
"""check_env.py — Valida que el entorno está listo para desarrollar BPA-Agent."""
import sys, subprocess, os
from pathlib import Path

OK = "\033[92m✅\033[0m"; ERR = "\033[91m❌\033[0m"; WARN = "\033[93m⚠️\033[0m"
errores = []

def run(cmd):
    try:
        r = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=8)
        return r.returncode == 0, r.stdout.strip()
    except Exception as e:
        return False, str(e)

print("\n🔍 BPA-Agent — Validación de Entorno\n")

# Python 3.11+
ok, v = run("python --version")
major, minor = (int(x) for x in v.split()[-1].split(".")[:2]) if ok else (0, 0)
meets = major > 3 or (major == 3 and minor >= 11)
print(f"{'OK' if meets else ERR} Python {v if ok else 'no encontrado'}" + (" ✓ ≥3.11" if meets else " ← Requiere 3.11+"))
if not meets: errores.append("Instalar Python 3.11+")

# Node 18+
ok, v = run("node --version")
node_major = int(v.lstrip("v").split(".")[0]) if ok else 0
meets = ok and node_major >= 18
print(f"{'OK' if meets else ERR} Node.js {v if ok else 'no encontrado'}" + (" ✓ ≥18" if meets else " ← Requiere Node 18+"))
if not meets: errores.append("Instalar Node.js 18+")

# Docker (recomendado)
ok, v = run("docker --version")
print(f"{'OK' if ok else WARN} Docker: {'✓' if ok else 'no instalado — recomendado pero no obligatorio'}")

# .env
env = Path(".env")
env_ex = Path(".env.example")
print(f"{'OK' if env_ex.exists() else ERR} .env.example: {'✓' if env_ex.exists() else 'no encontrado'}")
if not env_ex.exists(): errores.append("Crear .env.example")

if env.exists():
    content = env.read_text()
    print(f"{OK} .env: encontrado")
    for var in ["ANTHROPIC_API_KEY", "DATABASE_URL", "SECRET_KEY"]:
        present = f"{var}=" in content
        value = next((l.split("=",1)[1].strip() for l in content.splitlines() if l.startswith(f"{var}=")), "")
        filled = present and value not in ["", '""', "''"]
        print(f"  {'OK' if filled else ERR} {var}: {'✓' if filled else 'VACÍA — rellenar en .env'}")
        if not filled: errores.append(f"{var} vacía en .env")
else:
    print(f"{ERR} .env: no encontrado → copiar de .env.example y rellenar")
    errores.append(".env no existe")

# .env no en git
ok, out = run("git ls-files .env")
if ok and ".env" in out:
    print(f"{ERR} CRÍTICO: .env está en git → ejecutar: git rm --cached .env")
    errores.append(".env en git — CRÍTICO")
else:
    print(f"{OK} .env: no está en git ✓")

# Dependencias
ok, _ = run("python -c 'import fastapi'")
print(f"{'OK' if ok else WARN} FastAPI: {'instalado' if ok else 'ejecutar: pip install -r backend/requirements.txt'}")

nm = Path("frontend/node_modules")
print(f"{'OK' if nm.exists() else WARN} node_modules: {'✓' if nm.exists() else 'ejecutar: cd frontend && npm install'}")

# Resultado
print(f"\n{'='*45}")
if errores:
    print(f"\033[91m❌ {len(errores)} problema(s):\033[0m")
    for e in errores: print(f"  • {e}")
    sys.exit(1)
else:
    print(f"\033[92m✅ Todo OK. Listo para desarrollar.\033[0m")
    print("  Backend:  cd backend && uvicorn app.main:app --reload")
    print("  Frontend: cd frontend && npm run dev")
    print("  BD:       docker compose -f docker-compose.dev.yml up db -d")
