---
name: bpa-agent
description: >
  TFG Deusto — Agente BPA (Business Process Automation) con IA.
  ACTIVA SIEMPRE en este proyecto. Usar para cualquier tarea de desarrollo:
  backend, frontend, base de datos, agente IA, MCP, seguridad, tests, deploy,
  arquitectura, documentación, memoria TFG, o cuando el usuario mencione
  procesos, automatización, empresa, FastAPI, Next.js, Claude API, MCP,
  Anthropic, agente, sesión, progreso, fase, o cualquier tarea del TFG.
  También activa con /bpa-agent.
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
---

# BPA-Agent — Skill Maestra del TFG

## ═══════════════════════════════════════
## PROTOCOLO OBLIGATORIO — CADA SESIÓN
## ═══════════════════════════════════════

**PASO 1 — ANTES DE CUALQUIER OTRA COSA:**
```
Lee: references/01_ESTADO.md
```
Este archivo dice exactamente qué fase, qué toca hoy y qué está pendiente.

**PASO 2 — Confirmar con el usuario:**
```
"Según el estado del proyecto, estamos en [FASE] y toca [TAREA].
¿Confirmamos o hay algo diferente hoy?"
```

**PASO 3 — Plan de sesión (máximo 5 tareas):**
Lista concreta de lo que se va a hacer. Una tarea completada antes de la siguiente.

**PASO 4 — Al cerrar sesión, SIEMPRE:**
```
Actualiza references/01_ESTADO.md con:
- Tareas completadas (marca checkboxes)
- Archivos nuevos creados (añade a la tabla)
- Problemas encontrados y soluciones
- Próxima tarea
```

---

## ARCHIVOS DE REFERENCIA (cargar solo cuando sean necesarios)

| Archivo | Cuándo leerlo |
|---|---|
| `references/01_ESTADO.md` | **SIEMPRE** al iniciar sesión |
| `references/02_ARQUITECTURA.md` | Al crear carpetas, módulos, modelos de BD, endpoints |
| `references/03_SEGURIDAD.md` | Al escribir cualquier endpoint, auth, input de usuario |
| `references/04_STACK.md` | Al instalar dependencias o justificar decisiones técnicas |
| `references/05_AGENTE_IA.md` | Al trabajar con Claude API, prompts, streaming, MCP |
| `references/06_FRONTEND.md` | Al trabajar en Next.js, componentes, estado, API calls |
| `references/07_TESTS.md` | Al escribir tests o configurar pytest/playwright |
| `references/08_DEPLOY.md` | Al preparar Docker, Vercel, Railway, CI/CD |
| `references/09_MEMORIA_TFG.md` | Al redactar la memoria académica |

---

## REGLAS DE CÓDIGO — NO NEGOCIABLES

### Calidad
- Comentarios en español; nombres de variables/funciones en inglés (estándar industria)
- Docstring + tipo de retorno en cada función nueva
- Manejo de errores explícito — nunca `except: pass` ni `catch (e) {}`
- Logging en operaciones críticas — nunca `print()` en producción
- Máximo 50 líneas por función — si más, refactorizar

### Seguridad (ver 03_SEGURIDAD.md para código completo)
- CERO credenciales en código — solo `.env` + Pydantic Settings
- Validar TODO input con Pydantic antes de procesar
- Rate limiting en endpoints del agente IA
- CORS explícito — nunca `allow_origins=["*"]` en producción
- Solo ORM/queries parametrizadas — nunca f-strings en SQL
- Sanitizar input antes de enviar a Claude API (prompt injection)
- JWT: 15 min access token, 7 días refresh token

### Git
- Un cambio = un commit atómico
- Formato: `tipo(scope): descripción` — ej: `feat(agente): streaming SSE`
- Nunca commitear `.env`, `__pycache__`, `node_modules`, `.next`

### Tests
- Cada endpoint nuevo → test en `backend/tests/`
- Cobertura mínima 70% antes de cerrar una fase
- Tests de seguridad en endpoints críticos

---

## CUANDO ALGO FALLA

1. Leer el error completo — no asumir
2. Buscar en `01_ESTADO.md` sección "Problemas conocidos" — puede que ya ocurrió
3. Solución mínima primero, refactorizar después
4. Documentar en `01_ESTADO.md` → "Problemas conocidos"

---

## FASES DEL PROYECTO (resumen)

```
Fase 0 — Setup          (Semana 1)   → Entorno, Docker, BD, health check
Fase 1 — Backend MVP    (Sem 2-4)    → API REST, agente IA básico, tests
Fase 2 — Frontend MVP   (Sem 5-7)    → Dashboard, chat, mapa procesos
Fase 3 — Integraciones  (Sem 8-10)   → Gmail, Drive, Calendar, n8n MCP
Fase 4 — Refinamiento   (Sem 11-14)  → KPIs, demo Goikoetxea, deploy
Fase 5 — Memoria TFG    (Sem 15-18)  → Redacción, defensa, vídeo demo
```

Para detalle de cada fase → `references/02_ARQUITECTURA.md`
