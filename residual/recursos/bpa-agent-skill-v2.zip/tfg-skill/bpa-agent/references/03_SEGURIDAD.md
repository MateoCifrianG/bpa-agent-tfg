# 03 — SEGURIDAD
## Leer cuando: escribir endpoints, auth, procesar input de usuario, deploy

---

## REGLA ABSOLUTA #1 — CERO SECRETOS EN CÓDIGO

```python
# backend/app/config.py — PLANTILLA COMPLETA
from functools import lru_cache
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # App
    APP_NAME: str = "BPA-Agent"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "development"  # development | production

    # Seguridad
    SECRET_KEY: str                         # openssl rand -hex 32  — SIN DEFAULT
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # Base de datos
    DATABASE_URL: str                       # postgresql+asyncpg://...  — SIN DEFAULT

    # Anthropic
    ANTHROPIC_API_KEY: str                  # sk-ant-...  — SIN DEFAULT

    # MCP Servers
    GMAIL_MCP_URL: str = "https://gmailmcp.googleapis.com/mcp/v1"
    GDRIVE_MCP_URL: str = "https://drivemcp.googleapis.com/mcp/v1"
    GCALENDAR_MCP_URL: str = "https://calendarmcp.googleapis.com/mcp/v1"
    N8N_MCP_URL: str = "https://maxmaxdata.cloud/mcp-server/http"

    # CORS — en producción cambiar a dominio real
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000"]

    class Config:
        env_file = ".env"
        case_sensitive = True

@lru_cache()
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
```

---

## REGLA ABSOLUTA #2 — JWT CORRECTO

```python
# backend/app/auth/jwt.py
from datetime import datetime, timedelta, timezone
from jose import JWTError, jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from app.config import settings

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

def create_access_token(subject: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {"sub": subject, "exp": expire, "type": "access"}
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

def create_refresh_token(subject: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    payload = {"sub": subject, "exp": expire, "type": "refresh"}
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

def decode_token(token: str, expected_type: str = "access") -> dict:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        if payload.get("type") != expected_type:
            raise HTTPException(status_code=401, detail="Tipo de token incorrecto")
        return payload
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido o expirado",
            headers={"WWW-Authenticate": "Bearer"},
        )

async def get_current_user(token: str = Depends(oauth2_scheme), db=Depends(get_db)):
    payload = decode_token(token, expected_type="access")
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Token malformado")
    # Buscar usuario en BD — si no existe, denegar
    user = await db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=401, detail="Usuario no encontrado")
    return user
```

---

## REGLA ABSOLUTA #3 — VALIDAR TODO INPUT CON PYDANTIC

```python
# Ejemplo schema con validaciones estrictas
# backend/app/schemas/empresa.py
from pydantic import BaseModel, Field, field_validator
from typing import Literal
import re

class EmpresaCreate(BaseModel):
    nombre:      str     = Field(..., min_length=2, max_length=100)
    sector:      str     = Field(..., min_length=2, max_length=50)
    tamaño:      Literal["micropyme", "pequeña", "mediana"]
    descripcion: str     = Field(..., min_length=10, max_length=1000)

    @field_validator("nombre", "sector")
    @classmethod
    def solo_caracteres_validos(cls, v: str) -> str:
        if not re.match(r"^[a-zA-Z0-9\s\.,\-áéíóúñÁÉÍÓÚÑüÜ]+$", v):
            raise ValueError("Contiene caracteres no permitidos")
        return v.strip()

class ChatMessage(BaseModel):
    content:    str = Field(..., min_length=1, max_length=2000)
    empresa_id: str = Field(..., min_length=36, max_length=36)  # UUID
```

---

## REGLA ABSOLUTA #4 — RATE LIMITING

```python
# backend/app/main.py
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# En el router del agente
# backend/app/routers/agente.py
@router.post("/agente/chat")
@limiter.limit("20/minute")          # 20 mensajes/min por IP
@limiter.limit("200/hour")           # 200 mensajes/hora por IP
async def chat_agente(request: Request, ...):
    pass
```

---

## REGLA ABSOLUTA #5 — CORS EXPLÍCITO

```python
# backend/app/main.py
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,   # NUNCA ["*"] en producción
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
    max_age=600,
)
```

---

## REGLA ABSOLUTA #6 — CONTROL DE ACCESO POR EMPRESA

```python
# En TODOS los endpoints que devuelven datos de empresa
# NUNCA omitir esta verificación

async def verificar_acceso_empresa(
    empresa_id: str,
    current_user = Depends(get_current_user),
    db = Depends(get_db)
) -> Empresa:
    empresa = await db.get(Empresa, empresa_id)
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    if empresa.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Acceso denegado")
    return empresa
```

---

## REGLA ABSOLUTA #7 — SANITIZAR INPUT PARA EL AGENTE IA

```python
# backend/app/agents/safety.py
import re

# Patrones de prompt injection conocidos
INJECTION_PATTERNS = [
    r"ignore\s+(previous|all|prior)\s+instructions",
    r"you\s+are\s+now\s+",
    r"system\s*:\s*",
    r"<\s*system\s*>",
    r"jailbreak",
    r"DAN\s+mode",
    r"pretend\s+you\s+are",
    r"act\s+as\s+if",
    r"forget\s+(everything|all)",
]

def sanitize_user_input(text: str, max_length: int = 2000) -> str:
    """
    Limpia el input del usuario antes de enviarlo a Claude API.
    Lanza ValueError si detecta intento de prompt injection.
    """
    text = text[:max_length].strip()
    
    text_lower = text.lower()
    for pattern in INJECTION_PATTERNS:
        if re.search(pattern, text_lower):
            raise ValueError("Input rechazado: contiene patrones no permitidos")
    
    return text
```

---

## SEGURIDAD EN PRODUCCIÓN — HEADERS HTTP

```python
# backend/app/middleware/security_headers.py
from starlette.middleware.base import BaseHTTPMiddleware

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"]  = "nosniff"
        response.headers["X-Frame-Options"]          = "DENY"
        response.headers["X-XSS-Protection"]         = "1; mode=block"
        response.headers["Referrer-Policy"]           = "strict-origin-when-cross-origin"
        # Solo en HTTPS (producción):
        if request.url.scheme == "https":
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return response
```

---

## .gitignore — MÍNIMO OBLIGATORIO

```
# Secretos — NUNCA en git
.env
.env.*
!.env.example

# Python
__pycache__/
*.py[cod]
*.pyo
.pytest_cache/
.coverage
htmlcov/
dist/
*.egg-info/
venv/
.venv/

# Node
node_modules/
.next/
.vercel/
*.tsbuildinfo

# Misc
.DS_Store
*.log
```

---

## CHECKLIST SEGURIDAD ANTES DE CADA COMMIT

```bash
# Ejecutar siempre antes de git push
python .claude/skills/bpa-agent/scripts/audit_security.py
```

El script verifica automáticamente:
- No hay credenciales en código
- `.env` no está en git
- No hay SQL dinámico con f-strings
- CORS no tiene wildcard
- Pydantic en todos los routers POST/PUT
