# 06 — FRONTEND
## Leer cuando: crear componentes, páginas, estado, llamadas API, routing

---

## AXIOS CLIENT CON JWT AUTOMÁTICO

```typescript
// frontend/lib/api/client.ts
import axios, { AxiosInstance } from "axios";
import { useAuthStore } from "@/lib/store/authStore";

const api: AxiosInstance = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  timeout: 30000,
  headers: { "Content-Type": "application/json" },
});

// Inyectar token en cada request
api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Refresh automático si el access token expira
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      try {
        const refreshToken = useAuthStore.getState().refreshToken;
        const { data } = await axios.post(
          `${process.env.NEXT_PUBLIC_API_URL}/api/auth/refresh`,
          { refresh_token: refreshToken }
        );
        useAuthStore.getState().setAccessToken(data.access_token);
        original.headers.Authorization = `Bearer ${data.access_token}`;
        return api(original);
      } catch {
        useAuthStore.getState().logout();
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export default api;
```

---

## ZUSTAND STORES

```typescript
// frontend/lib/store/authStore.ts
import { create } from "zustand";
import { persist } from "zustand/middleware";

interface AuthState {
  accessToken:  string | null;
  refreshToken: string | null;
  user:         { id: string; email: string } | null;
  isAuth:       boolean;
  setTokens:    (access: string, refresh: string) => void;
  setAccessToken: (token: string) => void;
  logout:       () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      accessToken:  null,
      refreshToken: null,
      user:         null,
      isAuth:       false,
      setTokens: (access, refresh) =>
        set({ accessToken: access, refreshToken: refresh, isAuth: true }),
      setAccessToken: (token) => set({ accessToken: token }),
      logout: () =>
        set({ accessToken: null, refreshToken: null, user: null, isAuth: false }),
    }),
    { name: "bpa-auth", partialize: (s) => ({ refreshToken: s.refreshToken }) }
    // Solo persistir refreshToken — el access token se regenera
  )
);
```

```typescript
// frontend/lib/store/agenteStore.ts
import { create } from "zustand";

interface Mensaje {
  id:        string;
  role:      "user" | "assistant";
  content:   string;
  timestamp: Date;
}

interface AgenteState {
  mensajes:    Mensaje[];
  isStreaming: boolean;
  fase:        "entrevista" | "analisis" | "configuracion" | "ejecucion";
  addMensaje:  (msg: Omit<Mensaje, "id" | "timestamp">) => void;
  appendChunk: (chunk: string) => void;  // Añade al último mensaje del agente
  setFase:     (fase: AgenteState["fase"]) => void;
  setStreaming: (v: boolean) => void;
  reset:       () => void;
}

export const useAgenteStore = create<AgenteState>((set) => ({
  mensajes:    [],
  isStreaming: false,
  fase:        "entrevista",
  addMensaje: (msg) =>
    set((s) => ({
      mensajes: [...s.mensajes, { ...msg, id: crypto.randomUUID(), timestamp: new Date() }],
    })),
  appendChunk: (chunk) =>
    set((s) => {
      const msgs = [...s.mensajes];
      const last = msgs[msgs.length - 1];
      if (last?.role === "assistant") last.content += chunk;
      return { mensajes: msgs };
    }),
  setFase:     (fase) => set({ fase }),
  setStreaming: (v)   => set({ isStreaming: v }),
  reset:       ()     => set({ mensajes: [], fase: "entrevista" }),
}));
```

---

## TYPESCRIPT TYPES PRINCIPALES

```typescript
// frontend/lib/types/index.ts

export interface Empresa {
  id:          string;
  nombre:      string;
  sector:      string;
  tamaño:      "micropyme" | "pequeña" | "mediana";
  descripcion: string;
  created_at:  string;
}

export interface Proceso {
  id:                      string;
  empresa_id:              string;
  nombre:                  string;
  descripcion:             string;
  frecuencia:              "diario" | "semanal" | "mensual" | "eventual";
  tiempo_manual_horas:     number;
  herramientas_actuales:   string[];
  score_ineficiencia:      number | null;
  score_automatizabilidad: number | null;
}

export interface Automatizacion {
  id:                           string;
  proceso_id:                   string;
  nombre:                       string;
  descripcion:                  string;
  tipo:                         "email" | "calendario" | "documento" | "workflow";
  estado:                       "propuesta" | "aprobada" | "activa" | "pausada";
  tiempo_ahorrado_horas_semana: number | null;
  roi_estimado:                 number | null;
  activada_at:                  string | null;
}

export interface KPIResumen {
  tareas_automatizadas:     number;
  horas_ahorradas_semana:   number;
  roi_acumulado:            number;
  automatizaciones_activas: number;
  roi_proyeccion_anual:     number;
}
```

---

## REACT QUERY — PATRÓN ESTÁNDAR

```typescript
// Ejemplo para procesos — mismo patrón para todas las entidades
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getProcesos, analizarProceso } from "@/lib/api/procesos";

// Hook de lectura
export function useProcesos(empresaId: string) {
  return useQuery({
    queryKey: ["procesos", empresaId],
    queryFn:  () => getProcesos(empresaId),
    enabled:  !!empresaId,
    staleTime: 30_000,  // 30 segundos
  });
}

// Hook de mutación con invalidación automática
export function useAnalizarProceso() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: analizarProceso,
    onSuccess: (_, procesoId) => {
      qc.invalidateQueries({ queryKey: ["procesos"] });
    },
  });
}
```

---

## NEXT.JS — LAYOUT AUTENTICADO

```typescript
// frontend/app/(dashboard)/layout.tsx
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import Sidebar from "@/components/shared/Sidebar";
import Header  from "@/components/shared/Header";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Verificación server-side de sesión
  const cookieStore = cookies();
  const hasSession = cookieStore.get("has-session"); // Cookie no-httpOnly indicadora
  if (!hasSession) redirect("/login");

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
```

---

## NEXT.CONFIG.TS — REWRITE PARA PRODUCCIÓN

```typescript
// frontend/next.config.ts
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async rewrites() {
    return [
      {
        source:      "/api/:path*",
        destination: `${process.env.NEXT_PUBLIC_API_URL}/api/:path*`,
      },
    ];
  },
  // Seguridad: evitar exponer URLs del backend en el cliente
  serverRuntimeConfig: {
    apiUrl: process.env.API_URL,  // Solo server-side
  },
  publicRuntimeConfig: {
    apiUrl: process.env.NEXT_PUBLIC_API_URL,  // Cliente
  },
};

export default nextConfig;
```
