# 07 — TESTS
## Leer cuando: escribir tests, configurar cobertura, CI/CD

---

## CONFTEST.PY — FIXTURES BASE

```python
# backend/tests/conftest.py
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker

from app.main import app
from app.database import get_db
from app.models.base import Base
from app.auth.jwt import create_access_token

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture(scope="session")
async def engine():
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()

@pytest_asyncio.fixture
async def db_session(engine):
    factory = async_sessionmaker(engine, expire_on_commit=False)
    async with factory() as session:
        yield session
        await session.rollback()

@pytest_asyncio.fixture
async def client(db_session):
    async def override_get_db():
        yield db_session
    app.dependency_overrides[get_db] = override_get_db
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c
    app.dependency_overrides.clear()

@pytest.fixture
def auth_headers():
    token = create_access_token(subject="test-user-id")
    return {"Authorization": f"Bearer {token}"}
```

---

## TESTS DE EJEMPLO

```python
# backend/tests/test_empresas.py
import pytest

@pytest.mark.asyncio
async def test_crear_empresa_ok(client, auth_headers):
    response = await client.post("/api/empresas", json={
        "nombre": "Test S.L.", "sector": "Tecnología",
        "tamaño": "pequeña", "descripcion": "Empresa de prueba para tests."
    }, headers=auth_headers)
    assert response.status_code == 201
    data = response.json()
    assert data["nombre"] == "Test S.L."
    assert "id" in data

@pytest.mark.asyncio
async def test_crear_empresa_nombre_invalido(client, auth_headers):
    response = await client.post("/api/empresas", json={
        "nombre": "<script>alert('xss')</script>",
        "sector": "Tech", "tamaño": "pequeña", "descripcion": "Test."
    }, headers=auth_headers)
    assert response.status_code == 422  # Pydantic rechaza

@pytest.mark.asyncio
async def test_acceso_empresa_otro_usuario(client, auth_headers):
    # Crear empresa con usuario A, acceder con usuario B
    # Debe devolver 403
    ...
```

```python
# backend/tests/test_security.py
@pytest.mark.asyncio
async def test_sin_token_devuelve_401(client):
    response = await client.get("/api/empresas/123")
    assert response.status_code == 401

@pytest.mark.asyncio
async def test_token_expirado_devuelve_401(client):
    from jose import jwt
    from datetime import datetime, timezone
    expired = jwt.encode(
        {"sub": "user-id", "exp": datetime(2020, 1, 1, tzinfo=timezone.utc), "type": "access"},
        "secret", algorithm="HS256"
    )
    response = await client.get("/api/empresas/123",
                                headers={"Authorization": f"Bearer {expired}"})
    assert response.status_code == 401

@pytest.mark.asyncio
async def test_rate_limit_agente(client, auth_headers):
    # Enviar 25 mensajes rápidos — los últimos deben dar 429
    responses = []
    for _ in range(25):
        r = await client.post("/api/agente/chat",
            json={"content": "test", "empresa_id": "test-id"},
            headers=auth_headers)
        responses.append(r.status_code)
    assert 429 in responses
```

---
---

# 08 — DEPLOY
## Leer cuando: preparar Docker, Vercel, Railway, variables de entorno producción

---

## DOCKERFILE BACKEND (multi-stage)

```dockerfile
# backend/Dockerfile
FROM python:3.11-slim AS builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir --user -r requirements.txt

FROM python:3.11-slim AS production
WORKDIR /app
COPY --from=builder /root/.local /root/.local
COPY ./app ./app
ENV PATH=/root/.local/bin:$PATH
ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1
EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
```

## DOCKERFILE FRONTEND

```dockerfile
# frontend/Dockerfile
FROM node:20-alpine AS deps
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/public ./public
EXPOSE 3000
CMD ["node", "server.js"]
```

---

## DEPLOY EN PRODUCCIÓN

### Frontend → Vercel
```bash
# 1. Conectar repo GitHub a Vercel
# 2. Variables de entorno en Vercel dashboard:
NEXT_PUBLIC_API_URL=https://bpa-agent-api.railway.app

# 3. Deploy automático en cada push a main
```

### Backend + DB → Railway
```bash
# 1. Crear proyecto en Railway
# 2. Añadir PostgreSQL service
# 3. Añadir backend service desde GitHub
# 4. Variables de entorno en Railway:
DATABASE_URL=${{Postgres.DATABASE_URL}}
ANTHROPIC_API_KEY=sk-ant-...
SECRET_KEY=<openssl rand -hex 32>
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=15
REFRESH_TOKEN_EXPIRE_DAYS=7
ALLOWED_ORIGINS=https://bpa-agent.vercel.app
ENVIRONMENT=production
```

### Ejecutar migraciones en producción
```bash
# En Railway, añadir start command:
alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

---
---

# 09 — MEMORIA TFG
## Estructura completa + argumentos académicos listos para usar

---

## ESTRUCTURA RECOMENDADA (~85 páginas)

```
PORTADA
RESUMEN (español + inglés, 300 palabras)
ÍNDICE
LISTA DE FIGURAS Y TABLAS

CAPÍTULO 1 — INTRODUCCIÓN (8-10 pág)
  1.1 Motivación y contexto
      → PYMEs españolas pierden 20-30% tiempo en tareas manuales (McKinsey 2023)
      → Consultores caros, herramientas complejas, brecha de acceso a IA
  1.2 Objetivos del TFG
      → Objetivo general: Agente IA que democratiza automatización en PYMEs
      → Objetivos específicos (5-6 bullets técnicos)
  1.3 Alcance y limitaciones
  1.4 Estructura de la memoria

CAPÍTULO 2 — ESTADO DEL ARTE (15-20 pág)
  2.1 Transformación digital en PYMEs españolas
      → Cifras ONTSI 2024, Plan de Digitalización PYMEs 2021-2025
  2.2 Automatización de procesos: BPA vs RPA vs IA
      → RPA: frágil ante cambios de UI — BPA con IA: más resiliente
  2.3 Agentes de IA: arquitecturas 2024-2025
      → ReAct, Tool Use, Agentic Loops
  2.4 Model Context Protocol (MCP) — tecnología emergente
      → Anthropic 2024: estandarización de integraciones de agentes
  2.5 Análisis de soluciones existentes
      → Zapier, Make, n8n, Microsoft Copilot Studio — tabla comparativa
  2.6 Conclusión: hueco en el mercado que cubre este TFG

CAPÍTULO 3 — ANÁLISIS Y DISEÑO (15-20 pág)
  3.1 Análisis de requisitos
      → Funcionales (RF) y no funcionales (RNF) — tabla completa
  3.2 Casos de uso principales
      → Diagramas UML: UC-01 Entrevista empresa, UC-02 Análisis, UC-03 Activar
  3.3 Arquitectura del sistema
      → Diagrama de componentes (frontend, backend, agente, MCP, BD)
  3.4 Diseño de base de datos
      → Diagrama ER con 5 entidades y justificación
  3.5 Diseño del agente IA
      → Diagrama de estados: entrevista → análisis → configuración → ejecución
  3.6 Decisiones técnicas y justificación
      → Tabla del 04_STACK.md

CAPÍTULO 4 — IMPLEMENTACIÓN (25-30 pág)
  4.1 Entorno de desarrollo y estructura del proyecto
  4.2 Backend FastAPI
      → Modelos, schemas, routers, services, auth JWT
  4.3 Agente IA con Claude API
      → Sistema de prompts, streaming SSE, gestión de conversación
  4.4 Integraciones MCP
      → Gmail, Drive, Calendar, n8n — casos de uso reales
  4.5 Frontend Next.js
      → Dashboard, chat, mapa de procesos React Flow, KPIs
  4.6 Seguridad implementada
      → Rate limiting, Pydantic, JWT, sanitización prompt injection
  4.7 Testing y calidad
      → Cobertura ≥70%, tests de seguridad, E2E Playwright

CAPÍTULO 5 — VALIDACIÓN Y RESULTADOS (10-12 pág)
  5.1 Caso de uso real: Ferretería Goikoetxea S.L.
      → 4 procesos analizados, 2 automatizaciones activas
  5.2 Métricas de rendimiento
      → Tiempo respuesta API, latencia streaming, cobertura tests
  5.3 Resultados económicos
      → ROI calculado: X€/año ahorrados, Y horas/semana
  5.4 Evaluación de usabilidad (SUS score si es posible)

CAPÍTULO 6 — CONCLUSIONES (4-5 pág)
  6.1 Logros vs objetivos planteados
  6.2 Trabajo futuro
      → Multiempresa SaaS, más integraciones, app móvil
  6.3 Reflexión personal sobre el TFG

BIBLIOGRAFÍA (IEEE format, ~25-30 referencias)
ANEXO A — Manual de instalación
ANEXO B — Manual de usuario
ANEXO C — Documentación API (enlace a Swagger)
ANEXO D — Resultados completos de tests
```

---

## ARGUMENTOS ACADÉMICOS CLAVE

**¿Por qué este TFG es innovador?**
1. MCP es tecnología de 2024 — muy pocas implementaciones académicas publicadas
2. Agente con herramientas reales (no solo chatbot) — ejecución de acciones en empresa real
3. Medición de impacto cuantificable: ROI, horas ahorradas, KPIs
4. Stack completamente moderno y justificado con datos técnicos
5. Validado con empresa real/simulada del tejido empresarial vasco

**Cita imprescindible para la introducción:**
> Según el informe de McKinsey (2023), los trabajadores del conocimiento dedican
> un 60% de su tiempo a tareas de "procesamiento de trabajo" — búsqueda de
> información, comunicación rutinaria y actualización de datos — tareas
> automatizables con IA generativa.

**Para el estado del arte de MCP:**
> El Model Context Protocol (Anthropic, 2024) estandariza la comunicación entre
> agentes de IA y herramientas externas, resolviendo el problema de integración
> N×M que requería un adaptador por cada par (modelo, herramienta).
