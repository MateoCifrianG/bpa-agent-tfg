# 04 — STACK TECNOLÓGICO
## Versiones exactas. Justificación académica. Leer al instalar dependencias.

---

## requirements.txt (backend — producción)

```
# Web framework
fastapi==0.115.0
uvicorn[standard]==0.31.0
python-multipart==0.0.12

# Base de datos
sqlalchemy[asyncio]==2.0.36
alembic==1.13.3
asyncpg==0.30.0

# Validación y configuración
pydantic==2.9.2
pydantic-settings==2.5.2
python-dotenv==1.0.1

# Autenticación
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4

# IA
anthropic==0.40.0

# HTTP client (para MCP)
httpx==0.27.2

# Rate limiting
slowapi==0.1.9
```

## requirements-dev.txt (backend — desarrollo)

```
# Testing
pytest==8.3.3
pytest-asyncio==0.24.0
pytest-cov==5.0.0
httpx==0.27.2

# Linting
ruff==0.7.0
mypy==1.12.0

# Seguridad
safety==3.2.9
```

## package.json — dependencias clave frontend

```json
{
  "dependencies": {
    "next": "14.2.16",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "typescript": "^5.6.3",
    "@tanstack/react-query": "^5.59.16",
    "zustand": "^5.0.0",
    "axios": "^1.7.7",
    "reactflow": "^11.11.4",
    "recharts": "^2.13.0",
    "lucide-react": "^0.454.0",
    "tailwindcss": "^3.4.14",
    "clsx": "^2.1.1",
    "class-variance-authority": "^0.7.1"
  },
  "devDependencies": {
    "@playwright/test": "^1.48.0",
    "@types/node": "^20",
    "@types/react": "^18",
    "eslint": "^8.57.1",
    "@typescript-eslint/eslint-plugin": "^8.11.0"
  }
}
```

---

## pytest.ini

```ini
[pytest]
asyncio_mode = auto
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = --cov=app --cov-report=term-missing --cov-fail-under=70
```

---

## JUSTIFICACIÓN ACADÉMICA DE CADA DECISIÓN

Usar este apartado en la memoria TFG (Capítulo 3 — Análisis y diseño).

| Tecnología elegida | Alternativa descartada | Argumento técnico |
|---|---|---|
| **FastAPI** | Django REST Framework | Async nativo desde el core; documentación OpenAPI automática; 3× más rápido en benchmarks (TechEmpower 2024); ecosistema Python ideal para IA |
| **Next.js 14 App Router** | Vite + React SPA | SSR mejora SEO y tiempo de carga inicial; App Router permite layouts anidados; Server Components reducen JS al cliente; estándar Vercel 2024 |
| **PostgreSQL 16** | MongoDB | Soporte ACID para integridad de datos financieros (ROI, horas); JSON nativo para campos flexibles; relaciones complejas entre entidades; sin sacrificar esquema |
| **Claude API (Sonnet)** | OpenAI GPT-4o | MCP nativo sin adapters; mejor razonamiento sobre procesos empresariales complejos; streaming superior; contexto 200k tokens |
| **Pydantic v2** | marshmallow / cattrs | 10× más rápido que v1; integración nativa con FastAPI; type hints de Python, sin decoradores extra |
| **Zustand v5** | Redux Toolkit | Suficiente para este scope; mínimo boilerplate; sin Provider wrapper; TypeScript nativo |
| **React Flow** | D3.js custom | Drag-and-drop nativo; nodos custom; mantenido activamente; tiempo de desarrollo 5× menor que D3 |
| **JWT + Refresh Token** | Session cookies | Stateless; compatible SPA + API separados; escalable horizontalmente; estándar OAuth2 |
| **Docker Compose** | Bare metal | Reproducibilidad garantizada; onboarding en minutos; mismo entorno dev/prod; facilita demo TFG |
| **Alembic** | Creación manual tablas | Migraciones versionadas; rollback posible; historial de cambios en git |
| **slowapi** | Custom middleware | Integración nativa FastAPI; Redis-ready para producción; decorador simple por endpoint |

---

## CONFIGURACIÓN RUFF (linter Python)

```toml
# pyproject.toml
[tool.ruff]
line-length = 100
target-version = "py311"

[tool.ruff.lint]
select = ["E", "F", "W", "I", "N", "UP", "S", "B"]
ignore = ["S101"]  # Permitir assert en tests

[tool.mypy]
python_version = "3.11"
strict = true
ignore_missing_imports = true
```

---

## COMANDOS DE DESARROLLO

```bash
# ─── Backend ───────────────────────────────────────────
# Instalar dependencias
pip install -r requirements.txt -r requirements-dev.txt

# Arrancar en desarrollo
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Crear migración
alembic revision --autogenerate -m "descripcion"

# Aplicar migraciones
alembic upgrade head

# Tests con cobertura
pytest --cov=app --cov-report=html

# Linting
ruff check . && mypy app/

# Auditoría seguridad dependencias
safety check -r requirements.txt

# ─── Frontend ──────────────────────────────────────────
# Instalar
cd frontend && npm install

# Desarrollo
npm run dev

# Build producción
npm run build

# Tests E2E
npx playwright test

# ─── Docker ────────────────────────────────────────────
# Solo base de datos (para desarrollo local)
docker compose -f docker-compose.dev.yml up db -d

# Proyecto completo
docker compose -f docker-compose.dev.yml up

# Reconstruir imagen tras cambios en Dockerfile
docker compose -f docker-compose.dev.yml up --build
```
