# 02 — ARQUITECTURA DEL PROYECTO
## Leer cuando: crear carpetas, módulos, modelos BD, endpoints nuevos

---

## ESTRUCTURA COMPLETA DE CARPETAS

Cada archivo explicado. Crear exactamente esta estructura.

```
bpa-agent/                              ← RAÍZ DEL PROYECTO
│
├── .claude/                            ← Configuración Claude Code (no commitear contenido sensible)
│   └── skills/
│       └── bpa-agent/                  ← Esta skill
│
├── backend/                            ← API FastAPI (Python 3.11)
│   │
│   ├── app/
│   │   ├── __init__.py
│   │   │
│   │   ├── main.py                     ← Entry point. Registra routers, middleware, CORS, rate limiter
│   │   ├── config.py                   ← Pydantic Settings. Lee .env. NUNCA credenciales en código.
│   │   ├── database.py                 ← Engine async SQLAlchemy + función get_db() como dependency
│   │   │
│   │   ├── models/                     ← SQLAlchemy ORM — define tablas de la BD
│   │   │   ├── __init__.py             ← Exporta todos los modelos (necesario para Alembic)
│   │   │   ├── base.py                 ← DeclarativeBase + TimestampMixin (created_at, updated_at)
│   │   │   ├── empresa.py              ← Tabla: empresas
│   │   │   ├── proceso.py              ← Tabla: procesos (FK → empresas)
│   │   │   ├── automatizacion.py       ← Tabla: automatizaciones (FK → procesos)
│   │   │   ├── conversacion.py         ← Tabla: conversaciones (FK → empresas, mensajes en JSON)
│   │   │   └── kpi.py                  ← Tabla: kpi_snapshots (FK → empresas)
│   │   │
│   │   ├── schemas/                    ← Pydantic v2 — validación y serialización
│   │   │   ├── empresa.py              ← EmpresaCreate, EmpresaRead, EmpresaUpdate
│   │   │   ├── proceso.py              ← ProcesoCreate, ProcesoRead, ProcesoAnalisis
│   │   │   ├── automatizacion.py       ← AutomatizacionCreate, AutomatizacionRead, AutomatizacionConfig
│   │   │   ├── agente.py               ← ChatMessage, ChatResponse, StreamChunk, FaseEnum
│   │   │   ├── auth.py                 ← LoginRequest, TokenResponse, RefreshRequest
│   │   │   └── kpi.py                  ← KPIResumen, KPIHistorico, KPISnapshot
│   │   │
│   │   ├── routers/                    ← Endpoints HTTP — thin layer, lógica en services/
│   │   │   ├── __init__.py
│   │   │   ├── health.py               ← GET /api/health — devuelve status + versión
│   │   │   ├── auth.py                 ← POST /api/auth/login|refresh|logout
│   │   │   ├── empresas.py             ← CRUD /api/empresas
│   │   │   ├── procesos.py             ← CRUD + análisis /api/procesos
│   │   │   ├── agente.py               ← POST /api/agente/chat (streaming SSE)
│   │   │   ├── automatizaciones.py     ← CRUD + activar/pausar /api/automatizaciones
│   │   │   └── kpis.py                 ← GET /api/kpis/{empresa_id}/resumen|historico
│   │   │
│   │   ├── services/                   ← Lógica de negocio — aquí va la complejidad
│   │   │   ├── agente_service.py       ← Orquesta llamadas a Claude API, gestiona conversación
│   │   │   ├── analisis_service.py     ← Calcula scores ineficiencia/automatizabilidad
│   │   │   ├── mcp_service.py          ← Gestiona conexiones a MCP servers (Gmail, Drive, etc.)
│   │   │   └── kpi_service.py          ← Calcula KPIs, genera snapshots periódicos
│   │   │
│   │   ├── agents/                     ← Todo lo relacionado con el agente IA
│   │   │   ├── bpa_agent.py            ← Agente principal: gestiona fases y herramientas
│   │   │   ├── safety.py               ← Sanitiza input antes de enviar a Claude (prompt injection)
│   │   │   ├── tools/                  ← Herramientas que el agente puede invocar
│   │   │   │   ├── __init__.py
│   │   │   │   ├── analizar_proceso.py ← Analiza un proceso y calcula scores
│   │   │   │   ├── generar_propuesta.py ← Genera propuesta de automatización
│   │   │   │   ├── ejecutar_mcp.py     ← Ejecuta acciones via MCP servers
│   │   │   │   └── calcular_roi.py     ← Estima ROI de una automatización
│   │   │   └── prompts/                ← System prompts por fase del agente
│   │   │       ├── __init__.py
│   │   │       ├── entrevista.py       ← Prompt fase entrevista (ver 05_AGENTE_IA.md)
│   │   │       ├── analisis.py         ← Prompt fase análisis con salida JSON
│   │   │       ├── ejecucion.py        ← Prompt fase ejecución con MCP
│   │   │       └── monitor.py          ← Prompt generación informe KPIs
│   │   │
│   │   ├── auth/                       ← Autenticación y autorización
│   │   │   ├── jwt.py                  ← create_access_token, create_refresh_token, verify_token
│   │   │   └── dependencies.py         ← get_current_user FastAPI Depends
│   │   │
│   │   └── middleware/
│   │       ├── security_headers.py     ← X-Content-Type-Options, X-Frame-Options, HSTS
│   │       └── request_logging.py      ← Log de cada request (método, path, status, tiempo)
│   │
│   ├── alembic/                        ← Migraciones de base de datos
│   │   ├── versions/                   ← Archivos de migración generados automáticamente
│   │   ├── env.py                      ← Configuración Alembic (apunta a DATABASE_URL)
│   │   └── alembic.ini                 ← Config principal Alembic
│   │
│   ├── tests/
│   │   ├── conftest.py                 ← Fixtures: BD de test, cliente HTTP, tokens JWT
│   │   ├── test_health.py              ← Test básico de que la API responde
│   │   ├── test_auth.py                ← Login, refresh, logout, tokens expirados
│   │   ├── test_empresas.py            ← CRUD empresas + validaciones
│   │   ├── test_agente.py              ← Chat básico, streaming, límite rate
│   │   ├── test_procesos.py            ← CRUD + análisis de procesos
│   │   ├── test_automatizaciones.py    ← Flujo completo propuesta → activación
│   │   ├── test_kpis.py                ← Cálculo y snapshots
│   │   └── test_security.py            ← Inyección SQL, XSS, auth bypass, rate limit
│   │
│   ├── requirements.txt                ← Dependencias producción (ver 04_STACK.md)
│   ├── requirements-dev.txt            ← pytest, pytest-asyncio, pytest-cov, httpx
│   ├── Dockerfile                      ← Imagen producción (multi-stage build)
│   └── pytest.ini                      ← Configuración pytest + asyncio_mode=auto
│
├── frontend/                           ← Aplicación Next.js 14 App Router
│   │
│   ├── app/
│   │   ├── layout.tsx                  ← Root layout: fuentes, providers (QueryClient, Theme)
│   │   ├── globals.css                 ← Tailwind base + variables CSS custom
│   │   │
│   │   ├── (auth)/                     ← Rutas sin autenticación
│   │   │   ├── layout.tsx              ← Layout simple centrado
│   │   │   ├── login/
│   │   │   │   └── page.tsx            ← Formulario login → llama POST /api/auth/login
│   │   │   └── register/
│   │   │       └── page.tsx            ← Registro (si se implementa multiusuario)
│   │   │
│   │   └── (dashboard)/                ← Rutas protegidas — requieren JWT
│   │       ├── layout.tsx              ← Sidebar + header + verificación auth
│   │       ├── page.tsx                ← Home dashboard: resumen KPIs + accesos rápidos
│   │       ├── empresa/
│   │       │   └── page.tsx            ← Setup empresa primera vez (nombre, sector, tamaño)
│   │       ├── agente/
│   │       │   └── page.tsx            ← Chat con el agente BPA (streaming SSE)
│   │       ├── procesos/
│   │       │   └── page.tsx            ← Mapa visual de procesos (React Flow)
│   │       ├── propuestas/
│   │       │   └── page.tsx            ← Tarjetas de automatizaciones propuestas por IA
│   │       ├── automatizaciones/
│   │       │   └── page.tsx            ← Automatizaciones activas/pausadas + acciones
│   │       └── kpis/
│   │           └── page.tsx            ← Dashboard KPIs completo con gráficas Recharts
│   │
│   ├── components/
│   │   ├── ui/                         ← shadcn/ui — componentes base (Button, Card, Dialog...)
│   │   │
│   │   ├── agente/
│   │   │   ├── ChatWindow.tsx          ← Contenedor del chat con scroll automático
│   │   │   ├── MessageBubble.tsx       ← Burbuja usuario vs agente con markdown
│   │   │   ├── ChatInput.tsx           ← Input con botón enviar + estado loading
│   │   │   └── TypingIndicator.tsx     ← Animación "el agente está escribiendo..."
│   │   │
│   │   ├── procesos/
│   │   │   ├── ProcesoMapa.tsx         ← React Flow: nodos = procesos, edges = relaciones
│   │   │   ├── ProcesoNode.tsx         ← Nodo custom de React Flow con scores visuales
│   │   │   ├── ProcesoCard.tsx         ← Tarjeta resumen de un proceso
│   │   │   └── ScoreGauge.tsx          ← Gauge visual 0-100 para ineficiencia/automatizabilidad
│   │   │
│   │   ├── automatizaciones/
│   │   │   ├── PropuestaCard.tsx       ← Tarjeta propuesta: descripción, ROI, botón aprobar
│   │   │   ├── AutomatizacionRow.tsx   ← Fila en tabla de activas: estado, métricas, acciones
│   │   │   └── ActivacionModal.tsx     ← Modal confirmación antes de activar
│   │   │
│   │   ├── dashboard/
│   │   │   ├── KPICard.tsx             ← Tarjeta métrica: valor grande + tendencia + icono
│   │   │   ├── ROIChart.tsx            ← Recharts LineChart: ROI acumulado últimas semanas
│   │   │   ├── HorasChart.tsx          ← Recharts BarChart: horas ahorradas por semana
│   │   │   └── AutomatizacionesTimeline.tsx ← Timeline de cuándo se activó cada automatización
│   │   │
│   │   └── shared/
│   │       ├── Sidebar.tsx             ← Navegación lateral con iconos Lucide
│   │       ├── Header.tsx              ← Header con nombre empresa + usuario + logout
│   │       ├── LoadingSpinner.tsx      ← Spinner reutilizable
│   │       ├── ErrorBoundary.tsx       ← Captura errores React y muestra fallback
│   │       ├── ConfirmDialog.tsx       ← Dialog genérico para confirmar acciones destructivas
│   │       └── EmptyState.tsx          ← Placeholder cuando no hay datos
│   │
│   ├── lib/
│   │   ├── api/
│   │   │   ├── client.ts               ← Axios instance: baseURL, interceptors JWT, refresh automático
│   │   │   ├── auth.ts                 ← login(), logout(), refresh()
│   │   │   ├── empresas.ts             ← getEmpresa(), createEmpresa(), updateEmpresa()
│   │   │   ├── agente.ts               ← chatStream() usando fetch + ReadableStream para SSE
│   │   │   ├── procesos.ts             ← getProcesos(), createProceso(), analizarProceso()
│   │   │   ├── automatizaciones.ts     ← getAutomatizaciones(), activar(), pausar()
│   │   │   └── kpis.ts                 ← getResumen(), getHistorico()
│   │   │
│   │   ├── store/
│   │   │   ├── authStore.ts            ← Zustand: user, token, isAuthenticated, login/logout actions
│   │   │   ├── empresaStore.ts         ← Zustand: empresa actual, fase del agente
│   │   │   └── agenteStore.ts          ← Zustand: mensajes conversación, estado streaming
│   │   │
│   │   ├── types/
│   │   │   └── index.ts                ← Interfaces TypeScript: Empresa, Proceso, Automatizacion, KPI, etc.
│   │   │
│   │   └── utils/
│   │       ├── formatters.ts           ← formatEuros(), formatHoras(), formatFecha()
│   │       └── validators.ts           ← Validaciones frontend (email, campos requeridos)
│   │
│   ├── public/
│   │   └── favicon.ico
│   │
│   ├── Dockerfile
│   ├── next.config.ts                  ← rewrites para proxear /api → backend en producción
│   ├── tailwind.config.ts
│   ├── tsconfig.json
│   └── package.json
│
├── docker-compose.yml                  ← Producción: frontend, backend, postgres, redis(opcional)
├── docker-compose.dev.yml              ← Desarrollo: hot reload, puertos expuestos, volúmenes
├── .env.example                        ← Plantilla con todas las variables (sin valores reales)
├── .gitignore                          ← INCLUYE: .env, node_modules, __pycache__, .next, *.pyc
└── README.md                           ← Setup, arquitectura, cómo arrancar en local
```

---

## MODELOS DE BASE DE DATOS — CÓDIGO COMPLETO

```python
# backend/app/models/base.py
from datetime import datetime
from sqlalchemy import func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

class Base(DeclarativeBase):
    pass

class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        default=func.now(), onupdate=func.now(), nullable=False
    )
```

```python
# backend/app/models/empresa.py
from uuid import uuid4
from sqlalchemy import String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base, TimestampMixin

class Empresa(Base, TimestampMixin):
    __tablename__ = "empresas"
    
    id:          Mapped[str]  = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    nombre:      Mapped[str]  = mapped_column(String(100), nullable=False)
    sector:      Mapped[str]  = mapped_column(String(50),  nullable=False)
    tamaño:      Mapped[str]  = mapped_column(String(20),  nullable=False)  # micropyme|pequeña|mediana
    descripcion: Mapped[str]  = mapped_column(Text, nullable=False)
    
    procesos:       Mapped[list["Proceso"]]       = relationship(back_populates="empresa", cascade="all, delete-orphan")
    conversaciones: Mapped[list["Conversacion"]]  = relationship(back_populates="empresa", cascade="all, delete-orphan")
    kpi_snapshots:  Mapped[list["KPISnapshot"]]   = relationship(back_populates="empresa", cascade="all, delete-orphan")
```

```python
# backend/app/models/proceso.py
from uuid import uuid4
from sqlalchemy import String, Text, Float, JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base, TimestampMixin

class Proceso(Base, TimestampMixin):
    __tablename__ = "procesos"
    
    id:                       Mapped[str]        = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    empresa_id:               Mapped[str]        = mapped_column(ForeignKey("empresas.id"), nullable=False)
    nombre:                   Mapped[str]        = mapped_column(String(100), nullable=False)
    descripcion:              Mapped[str]        = mapped_column(Text, nullable=False)
    frecuencia:               Mapped[str]        = mapped_column(String(20), nullable=False)  # diario|semanal|mensual|eventual
    tiempo_manual_horas:      Mapped[float]      = mapped_column(Float, nullable=False)
    herramientas_actuales:    Mapped[list]       = mapped_column(JSON, default=list)
    score_ineficiencia:       Mapped[float|None] = mapped_column(Float, nullable=True)        # 0-100, calculado por IA
    score_automatizabilidad:  Mapped[float|None] = mapped_column(Float, nullable=True)        # 0-100, calculado por IA
    
    empresa:          Mapped["Empresa"]              = relationship(back_populates="procesos")
    automatizaciones: Mapped[list["Automatizacion"]] = relationship(back_populates="proceso", cascade="all, delete-orphan")
```

```python
# backend/app/models/automatizacion.py
from uuid import uuid4
from datetime import datetime
from sqlalchemy import String, Text, Float, JSON, ForeignKey, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base, TimestampMixin

class Automatizacion(Base, TimestampMixin):
    __tablename__ = "automatizaciones"
    
    id:                          Mapped[str]          = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    proceso_id:                  Mapped[str]          = mapped_column(ForeignKey("procesos.id"), nullable=False)
    nombre:                      Mapped[str]          = mapped_column(String(100), nullable=False)
    descripcion:                 Mapped[str]          = mapped_column(Text, nullable=False)
    tipo:                        Mapped[str]          = mapped_column(String(30), nullable=False)  # email|calendario|documento|workflow
    estado:                      Mapped[str]          = mapped_column(String(20), default="propuesta")  # propuesta|aprobada|activa|pausada
    config:                      Mapped[dict]         = mapped_column(JSON, default=dict)
    tiempo_ahorrado_horas_semana: Mapped[float|None]  = mapped_column(Float, nullable=True)
    roi_estimado:                Mapped[float|None]   = mapped_column(Float, nullable=True)
    activada_at:                 Mapped[datetime|None]= mapped_column(DateTime, nullable=True)
    
    proceso: Mapped["Proceso"] = relationship(back_populates="automatizaciones")
```

```python
# backend/app/models/conversacion.py
# mensajes = [{"role": "user"|"assistant", "content": "...", "timestamp": "ISO"}]

class Conversacion(Base, TimestampMixin):
    __tablename__ = "conversaciones"
    
    id:        Mapped[str]  = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    empresa_id:Mapped[str]  = mapped_column(ForeignKey("empresas.id"), nullable=False)
    fase:      Mapped[str]  = mapped_column(String(30), default="entrevista")  # entrevista|analisis|configuracion|ejecucion
    mensajes:  Mapped[list] = mapped_column(JSON, default=list)
    
    empresa: Mapped["Empresa"] = relationship(back_populates="conversaciones")
```

```python
# backend/app/models/kpi.py
from datetime import date
from sqlalchemy import Date, Integer, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base, TimestampMixin

class KPISnapshot(Base, TimestampMixin):
    __tablename__ = "kpi_snapshots"
    
    id:                       Mapped[str]   = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    empresa_id:               Mapped[str]   = mapped_column(ForeignKey("empresas.id"), nullable=False)
    fecha:                    Mapped[date]  = mapped_column(Date, nullable=False)
    tareas_automatizadas:     Mapped[int]   = mapped_column(Integer, default=0)
    horas_ahorradas_semana:   Mapped[float] = mapped_column(Float, default=0.0)
    roi_acumulado:            Mapped[float] = mapped_column(Float, default=0.0)
    automatizaciones_activas: Mapped[int]   = mapped_column(Integer, default=0)
    
    empresa: Mapped["Empresa"] = relationship(back_populates="kpi_snapshots")
```

---

## ENDPOINTS COMPLETOS

```
# HEALTH
GET  /api/health                                    → {"status": "ok", "version": "1.0.0"}

# AUTH
POST /api/auth/login                                ← {email, password} → {access_token, refresh_token}
POST /api/auth/refresh                              ← {refresh_token}   → {access_token}
POST /api/auth/logout                               ← {} (invalida refresh en BD)

# EMPRESAS
POST   /api/empresas                                ← EmpresaCreate → EmpresaRead
GET    /api/empresas/{id}                           → EmpresaRead (solo si pertenece al usuario)
PUT    /api/empresas/{id}                           ← EmpresaUpdate → EmpresaRead

# PROCESOS
GET    /api/procesos?empresa_id={id}               → list[ProcesoRead]
POST   /api/procesos                                ← ProcesoCreate → ProcesoRead
GET    /api/procesos/{id}                           → ProcesoRead
PUT    /api/procesos/{id}                           ← ProcesoUpdate → ProcesoRead
DELETE /api/procesos/{id}                           → {"deleted": true}
POST   /api/procesos/{id}/analizar                  → ProcesoRead (con scores actualizados)

# AGENTE
POST   /api/agente/chat                             ← ChatMessage → StreamingResponse (SSE)
POST   /api/agente/reset                            ← {} → {"reset": true}

# AUTOMATIZACIONES
GET    /api/automatizaciones?empresa_id={id}        → list[AutomatizacionRead]
POST   /api/automatizaciones                        ← AutomatizacionCreate → AutomatizacionRead
PUT    /api/automatizaciones/{id}                   ← AutomatizacionUpdate → AutomatizacionRead
DELETE /api/automatizaciones/{id}                   → {"deleted": true}
POST   /api/automatizaciones/{id}/aprobar           → AutomatizacionRead (estado: aprobada)
POST   /api/automatizaciones/{id}/activar           → AutomatizacionRead (estado: activa, ejecuta MCP)
POST   /api/automatizaciones/{id}/pausar            → AutomatizacionRead (estado: pausada)

# KPIs
GET    /api/kpis/{empresa_id}/resumen               → KPIResumen
GET    /api/kpis/{empresa_id}/historico?dias=30     → list[KPISnapshot]
POST   /api/kpis/{empresa_id}/snapshot              → KPISnapshot (forzar snapshot manual)
```

---

## DOCKER COMPOSE (desarrollo)

```yaml
# docker-compose.dev.yml
services:
  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: bpa_user
      POSTGRES_PASSWORD: bpa_pass
      POSTGRES_DB: bpa_agent
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U bpa_user -d bpa_agent"]
      interval: 5s
      timeout: 5s
      retries: 5

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    command: uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
    ports:
      - "8000:8000"
    volumes:
      - ./backend:/app
    env_file: .env
    depends_on:
      db:
        condition: service_healthy

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    command: npm run dev
    ports:
      - "3000:3000"
    volumes:
      - ./frontend:/app
      - /app/node_modules
      - /app/.next
    environment:
      - NEXT_PUBLIC_API_URL=http://localhost:8000
    depends_on:
      - backend

volumes:
  postgres_data:
```
