# 01 — ESTADO DEL PROYECTO
## Actualizar al INICIO y FINAL de cada sesión de trabajo

---

## SITUACIÓN ACTUAL

| Campo | Valor |
|---|---|
| **Fase activa** | 0 — Setup inicial |
| **Última sesión** | — pendiente primera sesión — |
| **Próxima tarea** | Crear estructura de carpetas del proyecto |
| **Bloqueado por** | Nada |
| **Horas invertidas** | 0 h |
| **Horas estimadas restantes** | ~120 h |

---

## PROGRESO POR FASES

### ▸ FASE 0 — Setup (Semana 1)
- [ ] Estructura de carpetas creada (ver 02_ARQUITECTURA.md)
- [ ] `docker-compose.yml` + `docker-compose.dev.yml`
- [ ] `.env.example` con todas las variables
- [ ] `.gitignore` correcto (nunca commitear .env)
- [ ] `README.md` inicial
- [ ] Conexión PostgreSQL verificada (`scripts/check_env.py`)
- [ ] Endpoint `GET /api/health` respondiendo 200

### ▸ FASE 1 — Backend MVP (Semanas 2–4)
- [ ] Modelos SQLAlchemy: Empresa, Proceso, Automatizacion, Conversacion, KPISnapshot
- [ ] Migraciones Alembic iniciales ejecutadas
- [ ] Auth JWT implementada (login, refresh, logout)
- [ ] `POST /api/empresas` con validación Pydantic
- [ ] `GET /api/empresas/{id}` con control de acceso
- [ ] `POST /api/agente/chat` sin streaming (versión simple)
- [ ] `POST /api/agente/chat` con streaming SSE
- [ ] System prompt entrevista funcionando
- [ ] System prompt análisis funcionando + scoring
- [ ] `POST /api/procesos/{id}/analizar` devuelve scores
- [ ] Rate limiting en endpoints del agente
- [ ] Tests unitarios ≥70% cobertura
- [ ] `scripts/audit_security.py` pasa sin críticos

### ▸ FASE 2 — Frontend MVP (Semanas 5–7)
- [ ] Layout dashboard Next.js 14 con sidebar
- [ ] Página `/empresa` — setup inicial empresa
- [ ] Página `/agente` — chat con streaming en tiempo real
- [ ] Página `/procesos` — mapa visual React Flow
- [ ] Página `/propuestas` — tarjetas de automatización propuestas
- [ ] Página `/automatizaciones` — gestión de activas/pausadas
- [ ] Axios client con interceptors JWT (refresh automático)
- [ ] Estado global Zustand: empresa + conversación
- [ ] Manejo de errores y estados de carga

### ▸ FASE 3 — Integraciones MCP (Semanas 8–10)
- [ ] Gmail MCP integrado (leer + enviar emails)
- [ ] Google Drive MCP integrado (leer + crear docs)
- [ ] Google Calendar MCP integrado (crear eventos)
- [ ] n8n MCP integrado (ejecutar workflows)
- [ ] Endpoint `POST /api/automatizaciones/{id}/activar` ejecuta real
- [ ] Tests E2E de cada integración
- [ ] `scripts/seed_db.py` con empresa Goikoetxea cargada

### ▸ FASE 4 — Refinamiento y Demo (Semanas 11–14)
- [ ] Página `/kpis` — dashboard completo con Recharts
- [ ] Datos demo Goikoetxea validados y funcionando
- [ ] Deploy frontend en Vercel
- [ ] Deploy backend en Railway
- [ ] Deploy DB en Railway PostgreSQL
- [ ] Dominio configurado
- [ ] Vídeo demo grabado (5-10 min)

### ▸ FASE 5 — Memoria TFG (Semanas 15–18)
- [ ] Capítulo 1 — Introducción
- [ ] Capítulo 2 — Estado del arte
- [ ] Capítulo 3 — Análisis y diseño
- [ ] Capítulo 4 — Implementación
- [ ] Capítulo 5 — Validación y resultados
- [ ] Capítulo 6 — Conclusiones
- [ ] Presentación defensa (20-30 slides)

---

## ARCHIVOS CREADOS

### Skills / Contexto
| Archivo | Descripción |
|---|---|
| `.claude/skills/bpa-agent/SKILL.md` | Entry point — protocolo sesión y reglas |
| `.claude/skills/bpa-agent/references/01_ESTADO.md` | Este archivo |
| `.claude/skills/bpa-agent/references/02_ARQUITECTURA.md` | Estructura completa del proyecto |
| `.claude/skills/bpa-agent/references/03_SEGURIDAD.md` | Código de seguridad listo para copiar |
| `.claude/skills/bpa-agent/references/04_STACK.md` | Versiones exactas + justificación académica |
| `.claude/skills/bpa-agent/references/05_AGENTE_IA.md` | Claude API, prompts, streaming, MCP |
| `.claude/skills/bpa-agent/references/06_FRONTEND.md` | Next.js, componentes, estado, routing |
| `.claude/skills/bpa-agent/references/07_TESTS.md` | Pytest, fixtures, cobertura, Playwright |
| `.claude/skills/bpa-agent/references/08_DEPLOY.md` | Docker, Vercel, Railway, CI/CD |
| `.claude/skills/bpa-agent/references/09_MEMORIA_TFG.md` | Estructura memoria + argumentos académicos |
| `.claude/skills/bpa-agent/scripts/check_env.py` | Validador de entorno pre-sesión |
| `.claude/skills/bpa-agent/scripts/audit_security.py` | Auditoría seguridad pre-commit |
| `.claude/skills/bpa-agent/scripts/seed_db.py` | Datos demo empresa Goikoetxea |

### Backend (se completa en Fase 1)
| Archivo | Descripción | Estado |
|---|---|---|
| `backend/app/main.py` | Entry point FastAPI | ⬜ pendiente |
| `backend/app/config.py` | Pydantic Settings | ⬜ pendiente |
| `backend/app/database.py` | Engine async PostgreSQL | ⬜ pendiente |

### Frontend (se completa en Fase 2)
| Archivo | Descripción | Estado |
|---|---|---|
| `frontend/app/layout.tsx` | Root layout con providers | ⬜ pendiente |

---

## VARIABLES DE ENTORNO REQUERIDAS
*(Solo nombres — nunca valores aquí)*

```
ANTHROPIC_API_KEY              # sk-ant-...
DATABASE_URL                   # postgresql+asyncpg://user:pass@host:5432/bpa_agent
SECRET_KEY                     # openssl rand -hex 32
ALGORITHM                      # HS256
ACCESS_TOKEN_EXPIRE_MINUTES    # 15
REFRESH_TOKEN_EXPIRE_DAYS      # 7
NEXT_PUBLIC_API_URL            # http://localhost:8000
```

---

## PROBLEMAS CONOCIDOS Y SOLUCIONES

| Problema | Solución | Fecha |
|---|---|---|
| — | — | — |

---

## DECISIONES TÉCNICAS TOMADAS

| Decisión | Alternativa descartada | Motivo |
|---|---|---|
| FastAPI sobre Django | Django | Async nativo, OpenAPI automático, ecosistema Python IA |
| Next.js 14 App Router | Vite+React | SSR, layouts anidados, Server Components |
| PostgreSQL | MongoDB | Relaciones complejas, ACID, JSON nativo |
| Claude API | OpenAI GPT-4 | MCP nativo, streaming superior, mejor razonamiento agente |
| Pydantic v2 | marshmallow | 10× más rápido, integración nativa FastAPI |
| Zustand | Redux | Suficiente scope, mínimo boilerplate |

---

## MÉTRICAS

| Métrica | Valor actual |
|---|---|
| Tareas completadas | 0 / ~50 |
| Endpoints creados | 0 |
| Cobertura tests | 0% |
| Horas invertidas | 0 h |
