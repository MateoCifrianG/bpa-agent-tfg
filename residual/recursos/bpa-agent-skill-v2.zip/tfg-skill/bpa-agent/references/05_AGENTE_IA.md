# 05 — AGENTE IA
## Leer cuando: trabajar con Claude API, prompts, streaming SSE, MCP servers

---

## ARQUITECTURA DEL AGENTE

El agente BPA tiene 4 fases. Cada fase tiene su propio system prompt.

```
FASE 1 — ENTREVISTA
  Usuario describe empresa → Agente hace preguntas adaptativas → Extrae procesos
  Modelo: claude-sonnet-4-20250514 | Temp: 0.7 | Max tokens: 500

FASE 2 — ANÁLISIS
  Procesos identificados → Agente analiza → Scores + propuestas en JSON
  Modelo: claude-sonnet-4-20250514 | Temp: 0.1 | Max tokens: 2000

FASE 3 — CONFIGURACIÓN
  Usuario aprueba propuesta → Agente pide datos necesarios → Configura
  Modelo: claude-sonnet-4-20250514 | Temp: 0.3 | Max tokens: 800

FASE 4 — EJECUCIÓN
  Agente ejecuta via MCP → Confirma resultado → Registra en KPIs
  Modelo: claude-sonnet-4-20250514 | Temp: 0.1 | Max tokens: 1000
```

---

## SISTEMA DE PROMPTS COMPLETO

```python
# backend/app/agents/prompts/entrevista.py
import json

def get_prompt_entrevista(empresa_nombre: str, sector: str, procesos: list) -> str:
    procesos_str = "\n".join(f"- {p['nombre']}: {p['descripcion']}" for p in procesos) \
        if procesos else "Ninguno identificado todavía."
    
    return f"""Eres BPA-Agent, consultor experto en transformación digital y automatización de procesos para PYMEs españolas.

EMPRESA: {empresa_nombre} | SECTOR: {sector}
PROCESOS YA IDENTIFICADOS:
{procesos_str}

MISIÓN: Mapear los procesos de la empresa para identificar qué puede automatizarse.

REGLAS ESTRICTAS:
- Una sola pregunta por mensaje. NUNCA dos seguidas.
- Empieza amplio (¿qué actividad principal?) y profundiza gradualmente.
- Para cada proceso nuevo: frecuencia, tiempo invertido, herramientas actuales, quién lo hace.
- Sé conversacional y cercano. Máximo 3 líneas por respuesta.
- Cuando tengas 3 o más procesos bien descritos, ofrece hacer el análisis.
- Si el usuario quiere pasar al análisis, responde: "FASE:ANALISIS"

ESTADO ACTUAL: {'Inicio de entrevista.' if not procesos else f'{len(procesos)} proceso(s) identificado(s). Continuar mapeando o pasar al análisis.'}"""
```

```python
# backend/app/agents/prompts/analisis.py
import json

def get_prompt_analisis(empresa_nombre: str, procesos: list) -> str:
    return f"""Analiza los procesos de {empresa_nombre} y devuelve ÚNICAMENTE un JSON válido, sin texto adicional, sin markdown.

PROCESOS A ANALIZAR:
{json.dumps(procesos, ensure_ascii=False, indent=2)}

FORMATO DE RESPUESTA (JSON exacto):
{{
  "analisis": [
    {{
      "proceso_id": "id del proceso",
      "proceso_nombre": "nombre",
      "score_ineficiencia": 75,
      "score_automatizabilidad": 82,
      "tiempo_ahorrado_horas_semana": 2.5,
      "propuesta": "descripción concreta de qué se automatizaría y cómo",
      "herramienta": "Gmail|Drive|Calendar|n8n",
      "roi_anual_euros": 3250.0,
      "complejidad": "baja|media|alta",
      "quick_win": true,
      "razonamiento": "por qué estos scores específicos"
    }}
  ],
  "resumen_ejecutivo": "2-3 líneas con el hallazgo principal",
  "top_3_prioridades": ["nombre_proceso_1", "nombre_proceso_2", "nombre_proceso_3"]
}}

CRITERIOS DE SCORING:
- score_ineficiencia >70: proceso manual repetitivo con reglas claras y bien definidas
- score_automatizabilidad >70: proceso digital, datos estructurados, sin decisiones subjetivas complejas
- quick_win = true: configurable en menos de 1 hora con Gmail, Drive o Calendar
- roi_anual_euros: (horas_ahorradas_semana × 52 × 25€/hora) × 0.7 (factor conservador)
- Ser realista y conservador — mejor sorprender positivamente que prometer demasiado"""
```

```python
# backend/app/agents/prompts/ejecucion.py
import json

def get_prompt_ejecucion(empresa_nombre: str, automatizacion: dict) -> str:
    return f"""Eres BPA-Agent en modo ejecución. Debes configurar y activar esta automatización.

EMPRESA: {empresa_nombre}
AUTOMATIZACIÓN APROBADA:
{json.dumps(automatizacion, ensure_ascii=False, indent=2)}

HERRAMIENTAS DISPONIBLES VIA MCP:
- Gmail: leer bandeja de entrada, enviar emails, crear filtros y etiquetas
- Google Drive: leer documentos, crear archivos, mover a carpetas
- Google Calendar: crear eventos, recordatorios, invitaciones recurrentes
- n8n: ejecutar workflows complejos, encadenar múltiples acciones

PROCESO OBLIGATORIO:
1. Explicar en 2 líneas exactamente qué vas a hacer
2. Solicitar datos que falten (plantillas, destinatarios, credenciales necesarias)
3. Ejecutar paso a paso, confirmando cada acción antes de la siguiente
4. Verificar que la automatización funciona correctamente
5. Reportar resultado final: éxito + métricas esperadas, o error + solución

RESTRICCIONES DE SEGURIDAD:
- NUNCA ejecutar acciones destructivas (borrar, vaciar) sin confirmación explícita
- NUNCA modificar datos ajenos a esta automatización
- Si hay un error, explicarlo antes de reintentar
- Si el usuario dice "cancelar" o "para", detener inmediatamente"""
```

```python
# backend/app/agents/prompts/monitor.py
import json

def get_prompt_monitor(empresa_nombre: str, autos_activas: list, kpi_data: dict) -> str:
    return f"""Genera un informe ejecutivo de KPIs para {empresa_nombre}.

AUTOMATIZACIONES ACTIVAS ({len(autos_activas)}):
{json.dumps(autos_activas, ensure_ascii=False)}

DATOS ÚLTIMAS 4 SEMANAS:
{json.dumps(kpi_data, ensure_ascii=False)}

GENERA (en español, tono ejecutivo, con números concretos):

**Resumen** (2-3 líneas con cifras reales)
**Logros del período** (máximo 3 puntos)
**Alertas** (solo si hay problemas reales — si todo va bien, omitir sección)
**Próxima oportunidad** (1 sugerencia basada en patrones observados)
**ROI** (acumulado actual → proyección a 12 meses con fórmula)

Sin tecnicismos innecesarios. El destinatario es el dueño de la empresa."""
```

---

## STREAMING SSE — IMPLEMENTACIÓN COMPLETA

```python
# backend/app/routers/agente.py
import json
from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
import anthropic
from app.config import settings
from app.auth.dependencies import get_current_user
from app.agents.safety import sanitize_user_input
from app.agents.prompts.entrevista import get_prompt_entrevista
from app.agents.prompts.analisis import get_prompt_analisis
from app.schemas.agente import ChatMessage

router = APIRouter(prefix="/api/agente", tags=["agente"])

@router.post("/chat")
@limiter.limit("20/minute")
async def chat_agente(
    request: Request,
    mensaje: ChatMessage,
    current_user=Depends(get_current_user),
    db=Depends(get_db)
):
    # Sanitizar input — lanza ValueError si hay prompt injection
    try:
        contenido_seguro = sanitize_user_input(mensaje.content)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    async def generate():
        client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        
        # Recuperar conversación de la BD
        conversacion = await get_or_create_conversacion(db, mensaje.empresa_id)
        
        # Seleccionar prompt según fase
        if conversacion.fase == "entrevista":
            system = get_prompt_entrevista(...)
        elif conversacion.fase == "analisis":
            system = get_prompt_analisis(...)
        
        # Construir historial
        mensajes_api = [
            {"role": m["role"], "content": m["content"]}
            for m in conversacion.mensajes[-20:]  # últimos 20 para no exceder contexto
        ]
        mensajes_api.append({"role": "user", "content": contenido_seguro})
        
        try:
            full_response = ""
            
            with client.messages.stream(
                model="claude-sonnet-4-20250514",
                max_tokens=1000,
                system=system,
                messages=mensajes_api,
            ) as stream:
                for text in stream.text_stream:
                    full_response += text
                    yield f"data: {json.dumps({'chunk': text, 'done': False})}\n\n"
            
            # Detectar cambio de fase
            if "FASE:ANALISIS" in full_response:
                await cambiar_fase(db, conversacion, "analisis")
            
            # Guardar en BD
            await guardar_mensajes(db, conversacion, contenido_seguro, full_response)
            
            yield f"data: {json.dumps({'chunk': '', 'done': True})}\n\n"
            
        except anthropic.APIError as e:
            yield f"data: {json.dumps({'error': str(e), 'done': True})}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Necesario para nginx
        }
    )
```

```typescript
// frontend/lib/api/agente.ts — consumir SSE en Next.js
export async function chatStream(
  content: string,
  empresaId: string,
  onChunk: (text: string) => void,
  onDone: () => void,
  onError: (err: string) => void
): Promise<void> {
  const token = useAuthStore.getState().accessToken;
  
  const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/agente/chat`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`,
    },
    body: JSON.stringify({ content, empresa_id: empresaId }),
  });
  
  if (!response.ok) {
    onError(`Error ${response.status}`);
    return;
  }
  
  const reader = response.body!.getReader();
  const decoder = new TextDecoder();
  
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    
    const chunk = decoder.decode(value);
    const lines = chunk.split("\n\n").filter(l => l.startsWith("data: "));
    
    for (const line of lines) {
      const data = JSON.parse(line.replace("data: ", ""));
      if (data.error) { onError(data.error); return; }
      if (data.chunk) onChunk(data.chunk);
      if (data.done) { onDone(); return; }
    }
  }
}
```

---

## MCP SERVERS — INTEGRACIÓN

```python
# backend/app/services/mcp_service.py
import httpx
from app.config import settings

MCP_SERVERS = {
    "gmail":     settings.GMAIL_MCP_URL,
    "drive":     settings.GDRIVE_MCP_URL,
    "calendar":  settings.GCALENDAR_MCP_URL,
    "n8n":       settings.N8N_MCP_URL,
}

async def ejecutar_via_mcp(
    servidor: str,
    herramienta: str,
    parametros: dict,
    timeout: int = 30
) -> dict:
    """
    Ejecuta una herramienta en un MCP server.
    
    Args:
        servidor: "gmail" | "drive" | "calendar" | "n8n"
        herramienta: nombre de la tool del MCP server
        parametros: parámetros específicos de la tool
        timeout: segundos máximo de espera
    
    Returns:
        Resultado de la ejecución
    
    Raises:
        HTTPException 502 si el MCP server no responde
        HTTPException 400 si los parámetros son incorrectos
    """
    url = MCP_SERVERS.get(servidor)
    if not url:
        raise ValueError(f"Servidor MCP desconocido: {servidor}")
    
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            response = await client.post(
                url,
                json={
                    "method": "tools/call",
                    "params": {
                        "name": herramienta,
                        "arguments": parametros
                    }
                },
                headers={"Content-Type": "application/json"}
            )
            response.raise_for_status()
            return response.json()
        except httpx.TimeoutException:
            raise HTTPException(502, f"MCP server {servidor} no respondió en {timeout}s")
        except httpx.HTTPStatusError as e:
            raise HTTPException(502, f"Error en MCP server {servidor}: {e.response.status_code}")
```

---

## EMPRESA DEMO — GOIKOETXEA

Para la demo del TFG, usar siempre esta empresa simulada:

```
Nombre: Ferretería Goikoetxea S.L.
Sector: Distribución industrial
Tamaño: Pequeña (12 empleados)
Ubicación: Bilbao, País Vasco

Procesos a automatizar:
1. Gestión pedidos por email  → Gmail MCP  → Ahorro: 2.5h/semana, ROI: 1.950€/año
2. Informe ventas semanal     → Drive MCP  → Ahorro: 2.5h/semana, ROI: 3.250€/año
3. Seguimiento presupuestos   → Gmail MCP  → Ahorro: 1.5h/semana, ROI: 1.950€/año
4. Onboarding proveedores     → Drive MCP  → Ahorro: 0.75h/mes,   ROI: 225€/año
```

Ejecutar `scripts/seed_db.py` para cargar estos datos automáticamente.
